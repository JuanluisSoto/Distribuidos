import sys
import logging
import pymysql
import json
import base64
from urllib.parse import parse_qs

rds_host = "35.174.142.83"

username = "admin"
password ="password"
dbname = "X"

bucketUrl = "https://samanta.barros.sisdis2023.s3.us-east-1.amazonaws.com/"

def verificar_tipo_archivo(nombre_archivo):
    # Obtener la extensión del archivo
    extension = nombre_archivo.split('.')[-1].lower()

    # Lista de extensiones comunes para imágenes
    extensiones_imagen = ['jpg', 'jpeg', 'png', 'gif', 'bmp']

    # Lista de extensiones comunes para videos
    extensiones_video = ['mp4', 'avi', 'mov', 'mkv', 'wmv']

    # Verificar si la extensión está en la lista de extensiones de imágenes
    if extension in extensiones_imagen:
        return 'img'
    # Verificar si la extensión está en la lista de extensiones de videos
    elif extension in extensiones_video:
        return 'video'
    else:
        return 'desconocido'
        
def lambda_handler(event , context):
    print(json.dumps(event));
    tipo_dato="err";
    user="err";
    comment="err";
    attachment="err";
    if "isBase64Encoded" in event:
        isEncoded=bool(event["isBase64Encoded"]);
    
        if isEncoded :
            decodedBytes = base64.b64decode(event["body"]);
            decodedStr = decodedBytes.decode("ascii") ;
            print(json.dumps(parse_qs(decodedStr)));
            decodedEvent=json.loads(json.dumps(parse_qs(decodedStr)));
            user=decodedEvent["user"][0];
            comment=decodedEvent["comment"][0];
            attachment=decodedEvent["attachment"][0];

    else:
        user=event["body"]["user"];
        comment=event["body"]["comment"];
        attachment=event["body"]["attachment"];
        
    print(user);
    tipo_dato=verificar_tipo_archivo(attachment);
    try:
        conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
        print(1);
        with conn.cursor() as cur:
            cur.execute("insert into Mensajes (name_user, message, dato, tipo_dato)values('"+user+"','"+comment+"','"+attachment+"','"+tipo_dato+"')");
            print(2);
            conn.commit();
            print(3);
            cur.close();
    except pymysql.MySQLError as e:    
        print (e)
    conn.close();
    print(4);
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : 'OK'    }
